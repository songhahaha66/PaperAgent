
"""Factories that write the four result workbooks following the provided templates."""
import numpy as np
from openpyxl import Workbook, load_workbook

TEMPLATE_HEADERS = {}
for _f, _sheets in [('result1', ['温度', '水分浓度']), ('result2', ['温度', '水分浓度']),
                    ('result3', ['Sheet1']), ('result4', ['Sheet1'])]:
    _wb = load_workbook(f'attachment/{_f}.xlsx', read_only=True)
    for _s in _sheets:
        _ws = _wb[_s]
        _row = next(_ws.iter_rows(min_row=1, max_row=1, values_only=True))
        TEMPLATE_HEADERS[(_f, _s)] = list(_row)
    _wb.close()


def r4(a):
    return np.round(np.asarray(a, dtype=float), 4)


def write_workbook(path, sheets, times):
    """sheets: list of (sheet_name, header_list, data ndarray (n_times, n_cols)).

    Empty/NaN cells are written as blanks (used where r exceeds the shrinking radius).
    """
    wb = Workbook(write_only=True)
    for name, header, data in sheets:
        ws = wb.create_sheet(name)
        ws.append(header)
        for i, t in enumerate(times):
            row = [int(round(t))]
            for v in data[i]:
                row.append(None if not np.isfinite(v) else float(v))
            ws.append(row)
    wb.save(path)
