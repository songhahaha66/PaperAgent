# research 已执行代码（按顺序，含探索及出错语句之前的完整前缀）。复用时复制需要的函数和处理步骤。

# 原执行环境镜像：paperagent-research:workspace-v2
# 在对应依赖环境中运行；不同库版本可能存在 API 差异。

import matplotlib
matplotlib.use("Agg")
from matplotlib.font_manager import fontManager

def choose_font(available):
    # Debian's Noto collection exposes its first face as CJK JP in Matplotlib;
    # it still contains Chinese glyphs. Match all regional CJK faces.
    preferred = ("Noto Sans CJK SC", "Noto Sans CJK JP", "Noto Sans CJK TC", "WenQuanYi Zen Hei",
                 "PingFang SC", "Heiti SC", "Microsoft YaHei", "SimHei", "Noto Sans SC", "Source Han Sans SC")
    return next((name for name in preferred if name in available),
                next((name for name in sorted(available) if name.startswith("Noto Sans CJK ")), "DejaVu Sans"))

matplotlib.rcParams["font.sans-serif"] = [choose_font({f.name for f in fontManager.ttflist})]
matplotlib.rcParams["axes.unicode_minus"] = False

# ---- run_20261101_104317_084678 ----

import os, glob
print(os.getcwd())
print(glob.glob('*')[:20])
print(glob.glob('attachment/*')[:20])

# ---- run_20261101_104342_2bf4bd ----

import pandas as pd, numpy as np
pd.set_option('display.width',200); pd.set_option('display.max_rows',300)

df1 = pd.read_excel('attachment/附件1.xlsx')
print(df1.shape, df1.columns.tolist())
print(df1.head(10)); print(df1.tail(10))
print(df1.describe())

df2 = pd.read_excel('attachment/附件2.xlsx')
print(df2.shape, df2.columns.tolist())
print(df2.head(5)); print(df2.tail(5)); print(df2.describe())
print("dt2:", np.diff(df2['时间'].values)[:5], df2['时间'].values[-1])

# ---- run_20261101_104407_8fc3ba ----

import pandas as pd, numpy as np, openpyxl
df1 = pd.read_excel('attachment/附件1.xlsx')
print(df1.iloc[::10].to_string())
print("---template headers---")
for f in ['result1','result2','result3','result4']:
    wb = openpyxl.load_workbook(f'attachment/{f}.xlsx')
    for ws in wb.worksheets:
        print(f, ws.title, ws.max_row, ws.max_column)
        for row in ws.iter_rows(min_row=1, max_row=min(4,ws.max_row), values_only=True):
            print("   ", row)

# ---- run_20261101_104420_d9e2de ----

try:
    import fitz
    doc = fitz.open('attachment/A题.pdf')
    for i,p in enumerate(doc):
        t = p.get_text()
        if '附' in t and ('2.' in t or '0.89' in t or '3850' in t):
            print('=== page',i+1,'===')
            print(t)
except Exception as e:
    print('ERR', e)

# ---- run_20261101_104433_c944a0 ----

import subprocess, sys
print(subprocess.run([sys.executable,'-m','pip','install','pymupdf','-q'],capture_output=True).stdout[-500:])
print(subprocess.run([sys.executable,'-m','pip','install','pymupdf','-q'],capture_output=True).stderr[-500:])

# ---- run_20261101_104447_ee4161 ----

import subprocess, sys
r = subprocess.run([sys.executable,'-m','pip','install','pymupdf','-q','--break-system-packages'],capture_output=True,text=True)
print(r.returncode, r.stdout[-300:], r.stderr[-300:])

# ---- run_20261101_104508_a271f9 ----

mods = {}
for m in ['pdfplumber','pypdf','PyPDF2','pdfminer']:
    try:
        __import__(m); mods[m]=True
    except Exception as e:
        mods[m]=str(e)
print(mods)

# ---- run_20261101_104623_6d2514 ----

import os
os.makedirs('code', exist_ok=True)
os.makedirs('outputs/figures', exist_ok=True)
src = r'''
"""Cylindrical (1D radial) coupled heat & moisture transfer solver for herb drying.

Model
-----
Heat:      rho(C) cp(C) dT/dt = (1/r) d/dr ( r k(C) dT/dr )
Moisture:  dC/dt = (1/r) d/dr ( r D(C,T) dC/dr )
BC: r=0 symmetry; r=R(t):  -k dT/dr = h (T-T_air),   -D dC/dr = hm (C-C_air)
Shrinking body: Lagrangian (Landau) coordinate xi = r/R(t); for a uniformly
shrinking cylinder the transformed equation keeps the divergence form with
R(t) in the metric, i.e. no explicit advection term.
Discretisation: cell-centred finite volume, backward Euler, Picard iteration.
"""
import numpy as np
from scipy.linalg import solve_banded
import pandas as pd

R0 = 0.02  # m, initial radius


# ---------------------------------------------------------------- properties
class PropsQ1:
    """Appendix 2 (problem 1)."""
    h, hm = 25.0, 8.0e-7
    def rho(self, C): return np.full_like(C, 820.0)
    def cp(self, C):  return np.full_like(C, 2600.0)
    def k(self, C):   return np.full_like(C, 0.36)
    def D(self, C, T):  # T in degC, unused
        return 7.0e-9 * np.exp(-0.89 / np.maximum(C, 1e-8))


class PropsQ23:
    """Appendix 3 (problems 2 and 3)."""
    h, hm = 25.0, 8.0e-7
    def rho(self, C): return 650.0 + 128.0 * C
    def cp(self, C):  return 1450.0 + 2736.0 * C / (C + 1.0)
    def k(self, C):   return 0.21 + 0.38 * C / (C + 1.0)
    def D(self, C, T):
        return (2.4e-3 * np.exp(-0.45 / np.maximum(C, 1e-8))
                * np.exp(-3850.0 / (T + 273.15)))


class PropsQ4:
    """Appendix 4 (problem 4), with prescribed shrinkage."""
    h, hm = 25.0, 8.0e-7
    def rho(self, C): return 760.0 + 90.0 * C
    def cp(self, C):  return 1850.0 + 2150.0 * C / (C + 1.0)
    def k(self, C):   return 0.12 + 0.20 * C / (C + 1.0)
    def D(self, C, T):
        return (4.2e-4 * np.exp(-0.30 / np.maximum(C, 1e-8))
                * np.exp(-3850.0 / (T + 273.15)))


# ---------------------------------------------------------------- ambient air
def load_ambient(path='attachment/附件1.xlsx'):
    df = pd.read_excel(path)
    t = df['时间'].values.astype(float)
    Ta = df['温度'].values.astype(float)
    Ca = df['水分浓度'].values.astype(float)
    return t, Ta, Ca


class Ambient:
    """Measured air state (附件1) up to t_switch, then constant drying stage."""
    def __init__(self, t, Ta, Ca, t_switch=14400.0, T_const=50.0, C_const=0.05):
        self.t, self.Ta, self.Ca = t, Ta, Ca
        self.t_switch, self.T_const, self.C_const = t_switch, T_const, C_const

    def __call__(self, tt):
        return (float(np.interp(tt, self.t, self.Ta)) if tt <= self.t_switch else self.T_const,
                float(np.interp(tt, self.t, self.Ca)) if tt <= self.t_switch else self.C_const)


def load_radius(path='attachment/附件2.xlsx'):
    df = pd.read_excel(path)
    return df['时间'].values.astype(float), df['半径'].values.astype(float) / 100.0  # -> m


class Radius:
    def __init__(self, t, R):
        self.t, self.R = t, R
    def __call__(self, tt):
        if tt >= self.t[-1]:
            return self.R[-1]
        return float(np.interp(tt, self.t, self.R))


class ConstRadius:
    def __init__(self, R=R0): self.Rv = R
    def __call__(self, tt): return self.Rv


# ---------------------------------------------------------------- solver
def _tridiag(lower, diag, upper, rhs):
    n = len(diag)
    ab = np.zeros((3, n))
    ab[0, 1:] = upper[:-1]
    ab[1, :] = diag
    ab[2, :-1] = lower[1:]
    return solve_banded((1, 1), ab, rhs)


def solve_cylinder(props, ambient, radius, t_end, dt, N=120, T0=28.0, C0=2.55,
                   r_samp=None, n_picard=2, store_stride=1):
    """Time integration. Returns (times, Tr, Cr) sampled at radii r_samp (m)."""
    if r_samp is None:
        r_samp = np.arange(0, 0.0200001, 0.001)      # 0.1 cm grid
    xi_f = np.arange(N + 1) / N
    xi_c = 0.5 * (xi_f[1:] + xi_f[:-1])
    dxi = 1.0 / N
    Avol = xi_f[1:] ** 2 - xi_f[:-1] ** 2            # 2*xi_c*dxi

    T = np.full(N, T0)
    C = np.full(N, C0)
    nt = int(round(t_end / dt))
    times = np.arange(nt + 1) * dt

    nsv = (nt // store_stride) + 1
    Tr = np.zeros((nsv, len(r_samp)))
    Cr = np.zeros((nsv, len(r_samp)))
    def record(k, tt):
        R = radius(tt)
        r = R * xi_c
        Tr[k] = np.interp(r_samp, r, T)
        Cr[k] = np.interp(r_samp, r, C)
    record(0, 0.0)
    k = 1

    for n in range(1, nt + 1):
        t_new = n * dt
        Rnew = radius(t_new)
        Rold = radius(t_new - dt)
        Tair, Cair = ambient(t_new)
        # ---- Picard iteration (lagged properties)
        Tp, Cp = T.copy(), C.copy()
        for it in range(n_picard):
            rho = props.rho(Cp); cp = props.cp(Cp); kk = props.k(Cp)
            kap = rho * cp
            Dc = props.D(Cp, Tp)
            # face conductivities (harmonic mean, mass-flux weighted)
            kf = 2 * kk[:-1] * kk[1:] / (kk[:-1] + kk[1:])
            Df = 2 * Dc[:-1] * Dc[1:] / (Dc[:-1] + Dc[1:])
            hs = props.h
            dr = Rnew * dxi
            Gs = 1.0 / (1.0 / hs + (dr / 2.0) / kk[-1])          # W/(m2 K)
            Hms = 1.0 / (1.0 / props.hm + (dr / 2.0) / Dc[-1])   # m/s

            # unknowns: temperatures at new time
            cap = kap * Rnew * xi_c * dxi / dt                    # per unit area 2*pi*R
            lo = np.zeros(N); di = np.zeros(N); up = np.zeros(N); rhs = np.zeros(N)
            # interior faces i+1/2 (i=0..N-2)
            cf = xi_f[1:-1] * kf / dxi
            for i in range(N):
                di[i] = cap[i]
                rhs[i] = cap[i] * T[i]
            di[:-1] += cf
            up[:-1] -= cf
            di[1:] += cf
            lo[1:] -= cf
            # outer boundary face
            cb = 1.0 * Gs * Rnew      # xi_f[-1]=1 ; q contribution
            di[-1] += cb
            rhs[-1] += cb * Tair
            Tnew = _tridiag(lo, di, up, rhs)

            capc = Rnew * xi_c * dxi / dt
            lo2 = np.zeros(N); di2 = np.zeros(N); up2 = np.zeros(N); rhs2 = np.zeros(N)
            cfc = xi_f[1:-1] * Df / dxi
            di2[:] = capc; rhs2[:] = capc * C
            di2[:-1] += cfc; up2[:-1] -= cfc
            di2[1:] += cfc; lo2[1:] -= cfc
            cbc = Hms * Rnew
            di2[-1] += cbc; rhs2[-1] += cbc * Cair
            Cnew = _tridiag(lo2, di2, up2, rhs2)
            # under-relaxation for stability at strong nonlinearity
            Tp = 0.5 * (Tp + Tnew)
            Cp = 0.5 * (Cp + Cnew)
        T, C = Tnew, Cnew
        if n % store_stride == 0:
            record(k, t_new)
            k += 1
    return times[:store_stride * (k - 1) + 1:store_stride], Tr[:k], Cr[:k]
'''
open('code/drying_model.py','w').write(src)
print(len(src))

# ---- run_20261101_104656_fed916 ----

src = r'''
"""Cylindrical (1D radial) coupled heat & moisture transfer solver for herb drying.

Governing equations (axisymmetric cylinder, t>0, 0<r<R(t)):
  heat :  rho(C) cp(C) dT/dt = (1/r) d/dr ( r k(C) dT/dr )
  moist:  dC/dt = (1/r) d/dr ( r D(C,T) dC/dr )
  r=0 : symmetry ;  r=R(t):  -k dT/dr = h (T - T_air(t)),  -D dC/dr = hm (C - C_air(t))
Shrinkage is prescribed by R(t) (附件2).  Using the Lagrangian coordinate
xi = r/R(t) the conservative form for a uniformly shrinking cylinder is
  rho cp R^2 xi dxi dT/dtau = [ xi_f k dT/dxi ]_{faces}
i.e. storage scales with R^2 and boundary fluxes with R (no advection term
appears for r-linear shrinkage velocity).  Discretisation: cell-centred finite
volume in xi, backward Euler in time, Picard iteration for the nonlinear
properties.
"""
import numpy as np
from scipy.linalg import solve_banded
import pandas as pd

R0 = 0.02  # m


# ---------------------------------------------------------------- properties
class PropsQ1:
    """附录2 (problem 1)."""
    h, hm = 25.0, 8.0e-7
    def rho(self, C): return np.full_like(C, 820.0)
    def cp(self, C):  return np.full_like(C, 2600.0)
    def k(self, C):   return np.full_like(C, 0.36)
    def D(self, C, T): return 7.0e-9 * np.exp(-0.89 / np.maximum(C, 1e-8))


class PropsQ23:
    """附录3 (problems 2, 3)."""
    h, hm = 25.0, 8.0e-7
    def rho(self, C): return 650.0 + 128.0 * C
    def cp(self, C):  return 1450.0 + 2736.0 * C / (C + 1.0)
    def k(self, C):   return 0.21 + 0.38 * C / (C + 1.0)
    def D(self, C, T):
        return (2.4e-3 * np.exp(-0.45 / np.maximum(C, 1e-8))
                * np.exp(-3850.0 / (T + 273.15)))


class PropsQ4:
    """附录4 (problem 4, shrinkage from 附件2)."""
    h, hm = 25.0, 8.0e-7
    def rho(self, C): return 760.0 + 90.0 * C
    def cp(self, C):  return 1850.0 + 2150.0 * C / (C + 1.0)
    def k(self, C):   return 0.12 + 0.20 * C / (C + 1.0)
    def D(self, C, T):
        return (4.2e-4 * np.exp(-0.30 / np.maximum(C, 1e-8))
                * np.exp(-3850.0 / (T + 273.15)))


# ---------------------------------------------------------------- ambient air
def load_ambient(path='attachment/附件1.xlsx'):
    df = pd.read_excel(path)
    return (df['时间'].values.astype(float), df['温度'].values.astype(float),
            df['水分浓度'].values.astype(float))


class Ambient:
    """Measured air state (附件1) up to t_switch, then constant drying stage."""
    def __init__(self, t, Ta, Ca, t_switch=14400.0, T_const=50.0, C_const=0.05):
        self.t, self.Ta, self.Ca = t, Ta, Ca
        self.t_switch, self.T_const, self.C_const = t_switch, T_const, C_const

    def __call__(self, tt):
        if tt <= self.t_switch:
            return float(np.interp(tt, self.t, self.Ta)), float(np.interp(tt, self.t, self.Ca))
        return self.T_const, self.C_const


def load_radius(path='attachment/附件2.xlsx'):
    df = pd.read_excel(path)
    return df['时间'].values.astype(float), df['半径'].values.astype(float) / 100.0  # m


class Radius:
    def __init__(self, t, R):
        self.t, self.R = np.asarray(t, float), np.asarray(R, float)
    def __call__(self, tt):
        if tt >= self.t[-1]:
            return float(self.R[-1])
        return float(np.interp(tt, self.t, self.R))


class ConstRadius:
    def __init__(self, R=R0): self.Rv = R
    def __call__(self, tt): return self.Rv


# ---------------------------------------------------------------- solver
def _tridiag(lower, diag, upper, rhs):
    n = len(diag)
    ab = np.zeros((3, n))
    ab[0, 1:] = upper[:-1]
    ab[1, :] = diag
    ab[2, :-1] = lower[1:]
    return solve_banded((1, 1), ab, rhs)


def solve_cylinder(props, ambient, radius, t_end, dt, N=120, T0=28.0, C0=2.55,
                   r_samp=None, n_picard=3, save_every=1, omega=0.6):
    """Backward-Euler FV integration.

    Returns dict(times, Tr, Cr, Tsurf, Csurf, flux_h, flux_m, Tair_t, Cair_t)
    where Tr/Cr are sampled at r_samp (m, absolute radius) and the flux series
    are the heat (W/m2) and moisture (kg/(m2 s)) fluxes leaving the surface.
    """
    if r_samp is None:
        r_samp = np.arange(0, 0.0200001, 0.001)
    xi_f = np.arange(N + 1) / N
    xi_c = 0.5 * (xi_f[1:] + xi_f[:-1])
    dxi = 1.0 / N
    Avol = xi_f[1:] ** 2 - xi_f[:-1] ** 2

    T = np.full(N, T0); C = np.full(N, C0)
    nt = int(round(t_end / dt))
    nsave = nt // save_every + 1
    out = dict(times=np.zeros(nsave), Tr=np.zeros((nsave, len(r_samp))),
               Cr=np.zeros((nsave, len(r_samp))), Tsurf=np.zeros(nsave),
               Csurf=np.zeros(nsave), flux_h=np.zeros(nsave), flux_m=np.zeros(nsave),
               Tair=np.zeros(nsave), Cair=np.zeros(nsave), R=np.zeros(nsave))
    ksave = 0

    def record(tt):
        nonlocal ksave
        R = radius(tt)
        Tair, Cair = ambient(tt)
        out['times'][ksave] = tt
        out['R'][ksave] = R
        out['Tair'][ksave] = Tair; out['Cair'][ksave] = Cair
        out['Tr'][ksave] = np.interp(r_samp, R * xi_c, T)
        out['Cr'][ksave] = np.interp(r_samp, R * xi_c, C)
        out['Tsurf'][ksave] = T[-1]; out['Csurf'][ksave] = C[-1]
        ksave += 1
    record(0.0)

    for n in range(1, nt + 1):
        t_new = n * dt
        Rnew = radius(t_new)
        Tair, Cair = ambient(t_new)
        dr = Rnew * dxi
        Tp, Cp = T.copy(), C.copy()
        for it in range(n_picard):
            rho = props.rho(Cp); cp = props.cp(Cp); kk = props.k(Cp)
            kap = rho * cp
            Dc = props.D(Cp, Tp)
            kf = 2 * kk[:-1] * kk[1:] / (kk[:-1] + kk[1:])
            Df = 2 * Dc[:-1] * Dc[1:] / (Dc[:-1] + Dc[1:])
            Gs = 1.0 / (1.0 / props.h + 0.5 * dr / kk[-1])
            Hms = 1.0 / (1.0 / props.hm + 0.5 * dr / Dc[-1])

            cap = kap * Rnew ** 2 * xi_c * dxi / dt
            cf = xi_f[1:-1] * kf / dxi
            di = cap.copy(); lo = np.zeros(N); up = np.zeros(N); rhs = cap * T
            di[:-1] += cf; up[:-1] -= cf
            di[1:] += cf; lo[1:] -= cf
            cb = Gs * Rnew
            di[-1] += cb; rhs[-1] += cb * Tair
            Tnew = _tridiag(lo, di, up, rhs)

            capc = Rnew ** 2 * xi_c * dxi / dt
            cfc = xi_f[1:-1] * Df / dxi
            di2 = capc.copy(); lo2 = np.zeros(N); up2 = np.zeros(N); rhs2 = capc * C
            di2[:-1] += cfc; up2[:-1] -= cfc
            di2[1:] += cfc; lo2[1:] -= cfc
            cbc = Hms * Rnew
            di2[-1] += cbc; rhs2[-1] += cbc * Cair
            Cnew = _tridiag(lo2, di2, up2, rhs2)
            if it < n_picard - 1:
                Tp = (1 - omega) * Tp + omega * Tnew
                Cp = (1 - omega) * Cp + omega * Cnew
        T, C = Tnew, Cnew
        if n % save_every == 0:
            record(t_new)
            out['flux_h'][ksave - 1] = props.h * (T[-1] - Tair)
            out['flux_m'][ksave - 1] = props.hm * (C[-1] - Cair)
    for key in ('times', 'Tr', 'Cr', 'Tsurf', 'Csurf', 'flux_h', 'flux_m', 'Tair', 'Cair', 'R'):
        out[key] = out[key][:ksave]
    return out
'''
open('code/drying_model.py','w').write(src)
print('written', len(src))

# ---- run_20261101_104714_934e61 ----

import numpy as np, sys
sys.path.insert(0,'code')
import drying_model as dm
from scipy.special import j0, j1
from scipy.optimize import brentq

# analytic test: constant props, step change of air temperature 28->50
class StepAmb:
    def __call__(self, tt): return 50.0, 0.0
props = dm.PropsQ1()
out = dm.solve_cylinder(props, StepAmb(), dm.ConstRadius(0.02), t_end=600, dt=1.0, N=120,
                        T0=28.0, C0=2.55, r_samp=np.arange(0,0.0200001,0.001))
h,k,R,alpha = 25.0,0.36,0.02,0.36/(820*2600)
Bi = h*R/k
# eigenvalues
roots=[]
x=1e-6
for n in range(60):
    lo=x+1e-6; hi=x+np.pi*0.999
    f=lambda z: z*j1(z)-Bi*j0(z)
    if f(lo)*f(hi)>0: 
        x=hi; continue
    r=brentq(f,lo,hi); roots.append(r); x=hi
lam=np.array(roots)
Cn = 2*j1(lam)/(lam*(j0(lam)**2+j1(lam)**2))
def theta_analytic(r,t):
    Fo = alpha*t/R**2
    return np.sum(Cn[:,None]*j0(lam[:,None]*np.array(r)[None,:]/R)*np.exp(-lam**2*Fo)[:,None],axis=0)
for tt in [60,180,300,600]:
    i = int(np.argmin(abs(out['times']-tt)))
    ra = np.array([0,0.01,0.02])
    Ta_an = 50 + (28-50)*theta_analytic(ra, tt)
    print(tt, out['Tr'][i][[0,10,20]].round(4), Ta_an.round(4), 'maxerr', np.abs(out['Tr'][i][[0,10,20]]-Ta_an).max().round(5))
print('energy check: stored vs flux integral')
dt=1.0
Ts=out['Tsurf']; flux=out['flux_h']; t=out['times']
Eflux = np.trapezoid(flux*(2*np.pi*R), t)   # per unit length, J/m
Estore = 820*2600*np.pi*R**2*(out['Tr'][-1].mean() if False else 0)
# volume-average temperature from fine radial integral (approx using 21 samples)
prof = out['Tr'][-1]
r = np.arange(0,0.0200001,0.001)
Tavg1 = np.trapezoid(prof*2*np.pi*r, r)/(np.pi*R**2)
Tavg0 = 28.0
print('Eflux',Eflux, 'Estore',820*2600*np.pi*R**2*(Tavg1-Tavg0))

# ---- run_20261101_104734_1bcbb3 ----

import re
src = open('code/drying_model.py').read()
old = """    def record(tt):
        nonlocal ksave
        R = radius(tt)
        Tair, Cair = ambient(tt)
        out['times'][ksave] = tt
        out['R'][ksave] = R
        out['Tair'][ksave] = Tair; out['Cair'][ksave] = Cair
        out['Tr'][ksave] = np.interp(r_samp, R * xi_c, T)
        out['Cr'][ksave] = np.interp(r_samp, R * xi_c, C)
        out['Tsurf'][ksave] = T[-1]; out['Csurf'][ksave] = C[-1]
        ksave += 1"""
new = """    def record(tt):
        nonlocal ksave
        R = radius(tt)
        Tair, Cair = ambient(tt)
        dr_ = R * dxi
        # surface values extrapolated from the surface energy/mass balance
        Ts = Tair - (props.k(C[-1]) / props.h) * (T[-1] - T[-2]) / dr_
        Cs = Cair - (props.D(C[-1], T[-1]) / props.hm) * (C[-1] - C[-2]) / dr_
        r_ext = np.append(R * xi_c, R)
        out['times'][ksave] = tt
        out['R'][ksave] = R
        out['Tair'][ksave] = Tair; out['Cair'][ksave] = Cair
        out['Tr'][ksave] = np.interp(r_samp, r_ext, np.append(T, Ts))
        out['Cr'][ksave] = np.interp(r_samp, r_ext, np.append(C, Cs))
        out['Tsurf'][ksave] = Ts; out['Csurf'][ksave] = Cs
        ksave += 1"""
assert old in src
src = src.replace(old, new)
open('code/drying_model.py','w').write(src)

import sys, numpy as np
sys.path.insert(0,'code')
import importlib, drying_model as dm
importlib.reload(dm)
from scipy.special import j0, j1
from scipy.optimize import brentq
class StepAmb:
    def __call__(self, tt): return 50.0, 0.0
props = dm.PropsQ1()
out = dm.solve_cylinder(props, StepAmb(), dm.ConstRadius(0.02), t_end=600, dt=1.0, N=120, r_samp=np.arange(0,0.0200001,0.001))
h,R,alpha = 25.0,0.02,0.36/(820*2600); Bi=h*R/0.36
roots=[];x=1e-6
for n in range(60):
    lo=x+1e-6; hi=x+np.pi*0.999
    f=lambda z: z*j1(z)-Bi*j0(z)
    if f(lo)*f(hi)>0: x=hi; continue
    roots.append(brentq(f,lo,hi)); x=hi
lam=np.array(roots); Cn=2*j1(lam)/(lam*(j0(lam)**2+j1(lam)**2))
def tha(r,t):
    Fo=alpha*t/R**2
    return np.sum(Cn[:,None]*j0(lam[:,None]*np.array(r)[None,:]/R)*np.exp(-lam**2*Fo)[:,None],axis=0)
for tt in [60,180,300,600]:
    i=int(np.argmin(abs(out['times']-tt))); ra=np.array([0,0.01,0.02])
    print(tt, out['Tr'][i][[0,10,20]].round(4), (50-22*tha(ra,tt)).round(4),
          'maxerr', np.abs(out['Tr'][i][[0,10,20]]-(50-22*tha(ra,tt))).max().round(5))
# energy balance with finer sampling
r_s=np.arange(0,0.0200001,0.001)
Eflux=np.trapezoid(out['flux_h']*2*np.pi*R, out['times'])
Tavg1=np.trapezoid(out['Tr'][-1]*2*np.pi*r_s,r_s)/(np.pi*R**2)
print('Eflux', round(Eflux,1), 'Estore', round(820*2600*np.pi*R**2*(Tavg1-28),1))

# ---- run_20261101_104759_a8b117 ----

import numpy as np, sys, importlib
sys.path.insert(0,'code'); import drying_model as dm; importlib.reload(dm)
from scipy.special import j0, j1
from scipy.optimize import brentq
class StepAmb:
    def __call__(self, tt): return 50.0, 0.0
h,R,alpha,k = 25.0,0.02,0.36/(820*2600),0.36
Bi=h*R/k
roots=[];x=1e-6
for n in range(60):
    lo=x+1e-6; hi=x+np.pi*0.999
    f=lambda z: z*j1(z)-Bi*j0(z)
    if f(lo)*f(hi)>0: x=hi; continue
    roots.append(brentq(f,lo,hi)); x=hi
lam=np.array(roots); Cn=2*j1(lam)/(lam*(j0(lam)**2+j1(lam)**2))
def tha(r,t):
    Fo=alpha*t/R**2
    return np.sum(Cn[:,None]*j0(lam[:,None]*np.array(r)[None,:]/R)*np.exp(-lam**2*Fo)[:,None],axis=0)
for N in [120,480]:
    out = dm.solve_cylinder(dm.PropsQ1(), StepAmb(), dm.ConstRadius(0.02), t_end=120, dt=0.5, N=N,
                            r_samp=np.array([0.017,0.019,0.0195,0.0199,0.02]))
    i=int(np.argmin(abs(out['times']-60)))
    rs=np.array([0.017,0.019,0.0195,0.0199,0.02])
    print('N=',N, out['Tr'][i].round(4), (50-22*tha(rs,60)).round(4), 'Tsurf_rec', round(out['Tsurf'][i],4))

# ---- run_20261101_104834_891d83 ----

import sys, importlib, numpy as np
src = open('code/drying_model.py').read()
old = """        Ts = Tair - (props.k(C[-1]) / props.h) * (T[-1] - T[-2]) / dr_
        Cs = Cair - (props.D(C[-1], T[-1]) / props.hm) * (C[-1] - C[-2]) / dr_"""
new = """        aT = props.h * (dr_ / 2) / props.k(C[-1])
        aC = props.hm * (dr_ / 2) / props.D(C[-1], T[-1])
        Ts = (T[-1] + aT * Tair) / (1.0 + aT)
        Cs = (C[-1] + aC * Cair) / (1.0 + aC)"""
assert old in src
open('code/drying_model.py','w').write(src.replace(old,new))

sys.path.insert(0,'code'); import drying_model as dm; importlib.reload(dm)
from scipy.special import j0, j1
from scipy.optimize import brentq
class StepAmb:
    def __call__(self, tt): return 50.0, 0.0
h,R,alpha,k = 25.0,0.02,0.36/(820*2600),0.36; Bi=h*R/k
roots=[];x=1e-6
for n in range(60):
    lo=x+1e-6; hi=x+np.pi*0.999
    f=lambda z: z*j1(z)-Bi*j0(z)
    if f(lo)*f(hi)>0: x=hi; continue
    roots.append(brentq(f,lo,hi)); x=hi
lam=np.array(roots); Cn=2*j1(lam)/(lam*(j0(lam)**2+j1(lam)**2))
def tha(r,t):
    Fo=alpha*t/R**2
    return np.sum(Cn[:,None]*j0(lam[:,None]*np.array(r)[None,:]/R)*np.exp(-lam**2*Fo)[:,None],axis=0)
rs=np.array([0,0.01,0.02])
for N in [60,120,240]:
  for dt in [5.0,2.0,1.0]:
    out = dm.solve_cylinder(dm.PropsQ1(), StepAmb(), dm.ConstRadius(0.02), t_end=600, dt=dt, N=N, r_samp=rs)
    errs=[]
    for tt in [60,180,600]:
        i=int(np.argmin(abs(out['times']-tt)))
        ana=50-22*tha(rs,tt); errs.append(np.abs(out['Tr'][i]-ana).max())
    print('N',N,'dt',dt,'maxerr', np.round(errs,4))

# ---- run_20261101_104855_ee5be1 ----

import sys, numpy as np, time, importlib
sys.path.insert(0,'code'); import drying_model as dm; importlib.reload(dm)
t0=time.time()
t_air, Ta, Ca = dm.load_ambient()
amb1 = dm.Ambient(t_air, Ta, Ca)
out1 = dm.solve_cylinder(dm.PropsQ1(), amb1, dm.ConstRadius(0.02), t_end=1800.0, dt=0.5, N=120,
                         r_samp=np.arange(0,0.0200001,0.001), n_picard=3, save_every=2)
print('runtime', round(time.time()-t0,1),'s')
T=out1['Tr']; C=out1['Cr']; tt=out1['times']
idx=[int(np.argmin(abs(tt-s))) for s in [100,300,600,900,1200,1500,1800]]
cols=[0,5,10,15,20]
print('time  T(0,0.5,1,1.5,2)')
for i in idx:
    print(int(tt[i]), T[i][cols].round(4))
print('time  C')
for i in idx:
    print(int(tt[i]), C[i][cols].round(4))
print('surf T/C end', out1['Tsurf'][-1], out1['Csurf'][-1], 'Tair', out1['Tair'][-1], 'Cair', out1['Cair'][-1])
# mass balance check (per unit length, kg/m)
r=np.arange(0,0.0200001,0.001)
M0=np.trapezoid(2.55*2*np.pi*r, r); M1=np.trapezoid(C[-1]*2*np.pi*r, r)
flux=out1['flux_m']*2*np.pi*0.02
print('removed by volume change', round(M0-M1,6), 'flux integral', round(np.trapezoid(flux, tt),6))

# ---- run_20261101_104914_70279a ----

import sys, numpy as np, time, importlib
sys.path.insert(0,'code'); import drying_model as dm; importlib.reload(dm)
t_air, Ta, Ca = dm.load_ambient(); amb1 = dm.Ambient(t_air, Ta, Ca)
res={}
for N in [120,240,480,960]:
    t0=time.time()
    o = dm.solve_cylinder(dm.PropsQ1(), amb1, dm.ConstRadius(0.02), t_end=1800.0, dt=1.0, N=N,
                          r_samp=np.array([0,0.0005,0.001,0.0015,0.002,0.01,0.02]), n_picard=3)
    i=-1
    print(N, 'T', o['Tr'][i].round(4), 'C', o['Cr'][i].round(4), 'time', round(time.time()-t0,1))
    res[N]=o

# ---- run_20261101_104935_f96308 ----

import sys, numpy as np, time, importlib
sys.path.insert(0,'code'); import drying_model as dm; importlib.reload(dm)
t_air, Ta, Ca = dm.load_ambient()
amb = dm.Ambient(t_air, Ta, Ca)
t0=time.time()
o = dm.solve_cylinder(dm.PropsQ23(), amb, dm.ConstRadius(0.02), t_end=259200.0, dt=10.0, N=120,
                      r_samp=np.arange(0,0.0200001,0.001), n_picard=3, save_every=6)
print('runtime', round(time.time()-t0,1))
tt=o['times']; C=o['Cr']; T=o['Tr']
for h in [0.5,1,2,3,6,12,24,36,48,60,72]:
    i=int(np.argmin(abs(tt-h*3600)))
    print(f"h={h:5.1f} Cmax={C[i].max():.4f} Csurf={C[i][-1]:.4f} Ccen={C[i][0]:.4f} Tcen={T[i][0]:.3f} Tsurf={T[i][-1]:.3f}")
print('min C ever', C.min())

# ---- run_20261101_105002_e2608f ----

import sys, numpy as np, time, importlib
sys.path.insert(0,'code'); import drying_model as dm; importlib.reload(dm)
t_air, Ta, Ca = dm.load_ambient(); amb = dm.Ambient(t_air, Ta, Ca)
rs=np.array([0,0.005,0.01,0.015,0.02])
cfgs=[(120,10.0,3),(120,5.0,3),(120,2.0,3),(240,10.0,3),(120,10.0,6)]
store={}
for N,dt,npic in cfgs:
    t0=time.time()
    o=dm.solve_cylinder(dm.PropsQ23(), amb, dm.ConstRadius(0.02), t_end=24*3600., dt=dt, N=N,
                        r_samp=rs, n_picard=npic, save_every=int(600/dt))
    store[(N,dt,npic)]=o
    print(N,dt,npic,'runtime',round(time.time()-t0,1))
for h in [3,12,24]:
    print('--- t=',h,'h')
    for key,o in store.items():
        i=int(np.argmin(abs(o['times']-h*3600)))
        print(key,'C',o['Cr'][i].round(4),'T',o['Tr'][i].round(3))

# ---- run_20261101_105053_41336b ----

for m in ['xlsxwriter','openpyxl','scipy','matplotlib']:
    try:
        mod=__import__(m); print(m, getattr(mod,'__version__','?'))
    except Exception as e:
        print(m,'MISSING',e)

# ---- run_20261101_105112_142d53 ----

out_src = r'''
"""Factories that write the four result workbooks following the provided templates."""
import numpy as np
from openpyxl import Workbook, load_workbook

TEMPLATE_HEADERS = {}
for _f, _sheets in [('result1', ['温度', '水分浓度']), ('result2', ['温度', '水分浓度']),
                    ('result3', ['Sheet1']), ('result4', ['Sheet1'])]:
    _wb = load_workbook(f'attachment/{_f}.xlsx', read_only=True)
    for _s in _sheets:
        _ws = _wb[_s]
        _row = next(_ws.iter_rows(min_row=1, max_row=1, values_only=True))
        TEMPLATE_HEADERS[(_f, _s)] = list(_row)
    _wb.close()


def r4(a):
    return np.round(np.asarray(a, dtype=float), 4)


def write_workbook(path, sheets, times):
    """sheets: list of (sheet_name, header_list, data ndarray (n_times, n_cols)).

    Empty/NaN cells are written as blanks (used where r exceeds the shrinking radius).
    """
    wb = Workbook(write_only=True)
    for name, header, data in sheets:
        ws = wb.create_sheet(name)
        ws.append(header)
        for i, t in enumerate(times):
            row = [int(round(t))]
            for v in data[i]:
                row.append(None if not np.isfinite(v) else float(v))
            ws.append(row)
    wb.save(path)
'''
open('code/writers.py','w').write(out_src)

import sys, numpy as np, importlib
sys.path.insert(0,'code')
import writers, drying_model as dm
importlib.reload(writers); importlib.reload(dm)
print(writers.TEMPLATE_HEADERS[('result1','温度')])
print(writers.TEMPLATE_HEADERS[('result4','Sheet1')])

# ---- run_20261101_105128_49d908 ----

import sys, numpy as np, time, importlib
sys.path.insert(0,'code'); import drying_model as dm, writers as wr
importlib.reload(dm); importlib.reload(wr)

rs = np.arange(0, 20.0001, 1.0)/1000.0   # 0..0.02 m step 0.001 m
t_air, Ta, Ca = dm.load_ambient()
amb1 = dm.Ambient(t_air, Ta, Ca)
t0=time.time()
o = dm.solve_cylinder(dm.PropsQ1(), amb1, dm.ConstRadius(0.02), t_end=1800.0, dt=0.5, N=120,
                      r_samp=rs, n_picard=3, save_every=2)
print('runtime', round(time.time()-t0,1), len(o['times']))
tt = o['times']
labels = [wr.TEMPLATE_HEADERS[('result1','温度')][0]] + [round(0.1*i,1) for i in range(21)]
rows = np.arange(1,1801)
T = np.array([np.interp(rows, tt, o['Tr'][:,j]) for j in range(21)]).T
C = np.array([np.interp(rows, tt, o['Cr'][:,j]) for j in range(21)]).T
wr.write_workbook('result1.xlsx', [('温度', labels, wr.r4(T)), ('水分浓度', labels, wr.r4(C))], rows)
np.savez_compressed('outputs/q1_fields.npz', times=tt, Tr=o['Tr'], Cr=o['Cr'], rs=rs,
                    Tsurf=o['Tsurf'], Csurf=o['Csurf'], flux_h=o['flux_h'], flux_m=o['flux_m'],
                    Tair=o['Tair'], Cair=o['Cair'])
print('wrote result1.xlsx')
import os; print(os.path.getsize('result1.xlsx')/1024,'KB')
# tables
sel_t=[100,300,600,900,1200,1500,1800]; cols=[0,5,10,15,20]
print('表1'); 
for s in sel_t:
    i=int(np.argmin(abs(tt-s))); print(s, ' & '.join(f'{o["Tr"][i][c]:.4f}' for c in cols))
print('表2')
for s in sel_t:
    i=int(np.argmin(abs(tt-s))); print(s, ' & '.join(f'{o["Cr"][i][c]:.4f}' for c in cols))
# save markdown table
with open('outputs/q1_tables.tex','w') as f:
    for name,arr in [('温度',o['Tr']),('水分浓度',o['Cr'])]:
        f.write(f'% {name}\n')
        for s in sel_t:
            i=int(np.argmin(abs(tt-s)))
            f.write(f"{s} & " + ' & '.join(f'{arr[i][c]:.4f}' for c in cols) + r' \\ ' + '\n')
print(open('outputs/q1_tables.tex').read()[:300])

# ---- run_20261101_105149_c9591e ----

import numpy as np
d=np.load('outputs/q1_fields.npz')
print(d['rs'])
print('C at 1800s', d['Cr'][-1].round(4))
print('T at 1800s', d['Tr'][-1].round(4))
print('C at 600s', d['Cr'][600].round(4))

# ---- run_20261101_105210_3ec35a ----

import numpy as np
from scipy.special import j0, j1
from scipy.optimize import brentq
# analytic cylinder with convective (Robin) BC, constant D, Bi=3.24, Fo at t
def series(Bi, Fo, r_over_R, nt=80):
    roots=[];x=1e-6
    for n in range(nt):
        lo=x+1e-6; hi=x+np.pi*0.999
        f=lambda z: z*j1(z)-Bi*j0(z)
        if f(lo)*f(hi)>0: x=hi; continue
        roots.append(brentq(f,lo,hi)); x=hi
    lam=np.array(roots); Cn=2*j1(lam)/(lam*(j0(lam)**2+j1(lam)**2))
    return np.sum(Cn[:,None]*j0(lam[:,None]*np.atleast_1d(r_over_R)[None,:])*np.exp(-lam**2*Fo)[:,None],axis=0)
D=7e-9*np.exp(-0.89/2.55); R=0.02; hm=8e-7; Bi=hm*R/D
print('D0',D,'Bi',Bi)
r=np.array([0,0.005,0.01,0.015,0.019,0.02])/0.02
for t in [600,1800]:
    Fo=D*t/R**2
    theta=series(Bi,Fo,r)
    Cair=0.03307 if t==1800 else 0.02428
    print(t,'Fo=%.4f'%Fo, (Cair+(2.55-Cair)*theta).round(4))
print('variable-D numeric at 1800:', np.array([2.55,2.5497,2.5382,2.3753,1.7806,1.5103]))

# ---- run_20261101_105226_189650 ----

import numpy as np, time, sys
sys.path.insert(0,'code'); import writers as wr
rows=20000; labels=['时间\\到药材中心的距离']+[round(0.1*i,1) for i in range(21)]
data=np.random.rand(rows,21).round(4)
t0=time.time()
wr.write_workbook('outputs/bench20k.xlsx',[('温度',labels,data),('水分浓度',labels,data)],np.arange(1,rows+1))
print('20k rows 2 sheets:', round(time.time()-t0,1),'s', round(__import__('os').path.getsize('outputs/bench20k.xlsx')/1e6,1),'MB')

# ---- run_20261101_105307_d61e13 ----

import sys, numpy as np, time, importlib
sys.path.insert(0,'code'); import drying_model as dm; importlib.reload(dm)
rs=np.arange(0,20.0001,1.0)/1000.0
t_air,Ta,Ca = dm.load_ambient(); amb = dm.Ambient(t_air,Ta,Ca)
t0=time.time()
o = dm.solve_cylinder(dm.PropsQ23(), amb, dm.ConstRadius(0.02), t_end=80*3600., dt=10.0, N=120,
                      r_samp=rs, n_picard=3, save_every=1)
print('runtime',round(time.time()-t0,1))
tt=o['times']; C=o['Cr']; T=o['Tr']
Cmax=C.max(axis=1)
idx=np.argmax(Cmax<0.15)
print('drying end approx', tt[idx], tt[idx]/3600, 'h ; prev Cmax', Cmax[idx-1], 'Cmax now', Cmax[idx])
# refine with interpolation
from numpy import interp
print('Cmax at 50,55,56,57,58,60 h:', [round(Cmax[int(np.argmin(abs(tt-h*3600)))],4) for h in [50,55,56,57,58,60]])
np.savez_compressed('outputs/q23_fields.npz', times=tt, Tr=T, Cr=C, rs=rs, Tsurf=o['Tsurf'],
                    Csurf=o['Csurf'], Tair=o['Tair'], Cair=o['Cair'], flux_h=o['flux_h'], flux_m=o['flux_m'])
print('saved')

# ---- run_20261101_105359_dc2123 ----

import sys, numpy as np, time, importlib
sys.path.insert(0,'code'); import writers as wr; importlib.reload(wr)
d=np.load('outputs/q23_fields.npz')
tt=d['times']; T=d['Tr']; C=d['Cr']; rs=d['rs']
Cmax=C.max(axis=1)
i_end=int(np.argmax(Cmax<0.15))
# sub-step refine: find crossing by interpolating Cmax in time
t_end_dry = tt[i_end]
if i_end>0:
    t0_,t1_=tt[i_end-1],tt[i_end]; c0_,c1_=Cmax[i_end-1],Cmax[i_end]
    t_end_dry = t0_ + (c0_-0.15)/(c0_-c1_)*(t1_-t0_)
print('t_dry =',t_end_dry,'s =',round(t_end_dry/3600,3),'h')
T_dry_s = int(np.floor(t_end_dry))
labels=[wr.TEMPLATE_HEADERS[('result2','温度')][0]]+[round(0.1*i,1) for i in range(21)]
rows1=np.arange(1,T_dry_s+1)
T1=np.array([np.interp(rows1,tt,T[:,j]) for j in range(21)]).T
C1=np.array([np.interp(rows1,tt,C[:,j]) for j in range(21)]).T
t0=time.time()
wr.write_workbook('result2.xlsx',[('温度',labels,wr.r4(T1)),('水分浓度',labels,wr.r4(C1))],rows1)
print('result2 written', round(time.time()-t0,1),'s rows',len(rows1))
np.savez_compressed('outputs/q23_result_arrays.npz',rows1=rows1,T1=T1,C1=C1,t_dry=t_end_dry)
# result3: 60 s up to drying end
rows3=np.arange(60, T_dry_s+1, 60)
T3=np.array([np.interp(rows3,tt,T[:,j]) for j in range(21)]).T
C3=np.array([np.interp(rows3,tt,C[:,j]) for j in range(21)]).T
labels3=[wr.TEMPLATE_HEADERS[('result3','Sheet1')][0]]+[round(0.1*i,1) for i in range(21)]
t0=time.time()
wr.write_workbook('result3.xlsx',[('Sheet1',labels3,wr.r4(C3))],rows3)
print('result3 written',round(time.time()-t0,1),'s rows',len(rows3), 'last t',rows3[-1])
import os
print('sizes MB', round(os.path.getsize('result2.xlsx')/1e6,1), round(os.path.getsize('result3.xlsx')/1e6,2))

# ---- run_20261101_105734_daa436 ----

import sys, numpy as np, time, importlib
sys.path.insert(0,'code'); import drying_model as dm, pandas as pd; importlib.reload(dm)
rt, rR = dm.load_radius()
print('radius samples', rt[:6], rR[:6]*100)
# when does radius stop changing
dr=np.abs(np.diff(rR)); print('last change at', rt[:-1][dr>1e-9][-1], 'h', rt[:-1][dr>1e-9][-1]/3600)
rs=np.arange(0,20.0001,1.0)/1000.0
t_air,Ta,Ca=dm.load_ambient(); amb=dm.Ambient(t_air,Ta,Ca)
rad=dm.Radius(rt,rR)
t0=time.time()
o4=dm.solve_cylinder(dm.PropsQ4(), amb, rad, t_end=259200.0, dt=10.0, N=120, r_samp=rs, n_picard=3, save_every=1)
print('runtime',round(time.time()-t0,1))
tt=o4['times']; C=o4['Cr']; T=o4['Tr']; R=o4['R']
Cmax=C.max(axis=1)
for h in [1,3,6,12,24,36,48,60,72]:
    i=int(np.argmin(abs(tt-h*3600)))
    print(f"h={h:5.1f} R={R[i]*100:.4f}cm Cmax={Cmax[i]:.4f} Ccen={C[i][0]:.4f} Csurf={o4['Csurf'][i]:.4f} Tcen={T[i][0]:.2f}")
print('Cmax<0.15 ever?', Cmax.min(), 'at', tt[np.argmax(Cmax<0.15)] if (Cmax<0.15).any() else 'never')
np.savez_compressed('outputs/q4_fields.npz', times=tt, Tr=T, Cr=C, rs=rs, R=R, Tsurf=o4['Tsurf'],
                    Csurf=o4['Csurf'], Tair=o4['Tair'], Cair=o4['Cair'], flux_m=o4['flux_m'], flux_h=o4['flux_h'])

# ---- run_20261101_105822_7a9ebb ----

import sys, numpy as np, time, importlib
sys.path.insert(0,'code'); import writers as wr; importlib.reload(wr)
d4=np.load('outputs/q4_fields.npz'); tt=d4['times']; C=d4['Cr']; T=d4['Tr']; R=d4['R']; rs=d4['rs']
Cmax=C.max(axis=1); i_end=int(np.argmax(Cmax<0.15))
c0,c1=Cmax[i_end-1],Cmax[i_end]; t0_,t1_=tt[i_end-1],tt[i_end]
t_dry4=t0_+(c0-0.15)/(c0-c1)*(t1_-t0_)
print('Q4 t_dry',t_dry4,'s =',round(t_dry4/3600,3),'h ; R at end', R[i_end]*100)
Td=int(np.floor(t_dry4))
# ---- result4: 60 s rows, columns 0..2.0 cm step 0.1, blank where r>R(t)
rows4=np.arange(60,Td+1,60)
C4=np.zeros((len(rows4),21)); Rr=np.interp(rows4,tt,R); Cs=np.interp(rows4,tt,d4['Csurf'])
for j in range(21):
    C4[:,j]=np.interp(rows4,tt,C[:,j])
for i,r in enumerate(Rr):
    C4[i, rs > r+1e-12] = np.nan
labels4=[wr.TEMPLATE_HEADERS[('result4','Sheet1')][0]]+[round(0.1*i,1) for i in range(21)]+['药材表面']
data4=np.column_stack([C4, Cs])
wr.write_workbook('result4.xlsx',[('Sheet1',labels4,wr.r4(data4))],rows4)
np.savez_compressed('outputs/q4_result_arrays.npz',rows4=rows4,C4=C4,Cs=Cs,R=Rr,t_dry=t_dry4)
import os; print('result4 rows',len(rows4),'size KB',round(os.path.getsize('result4.xlsx')/1024,1))

# ---- tables
d23=np.load('outputs/q23_fields.npz'); t2=d23['times']; T23=d23['Tr']; C23=d23['Cr']
cols=[0,5,10,15,20]
def row(arr,t,cols):
    i=int(np.argmin(abs(t2-t))); return ' & '.join(f'{arr[i][c]:.4f}' for c in cols)
print('\n表3 (T, 0/0.5/1/1.5/2 cm)')
for h in [0.5,1,1.5,2,2.5,3.0]:
    print(f'{h:.1f} & '+row(T23,h*3600,cols)+r' \\')
print('\n表4 (C)')
for h in [0.5,1,1.5,2,2.5,3.0]:
    print(f'{h:.1f} & '+row(C23,h*3600,cols)+r' \\')
print('\n表2重复 check at 1800s? (Q2 vs Q1 differ by props)')
print('\n表5 (C every 6h)')
for h in range(6,58,6):
    print(f'{h} & '+row(C23,h*3600,cols)+r' \\')
print(f'{t_dry4=}')
i=int(np.argmin(abs(t2-t_dry4)))
print(f'{round(t2[i]/3600,2)} & '+' & '.join(f'{C23[i][c]:.4f}' for c in cols)+r' \\')

# ---- run_20261101_105849_b892fc ----

import sys, numpy as np, json, time
sys.path.insert(0,'code'); import drying_model as dm
rs=np.arange(0,20.0001,1.0)/1000.0
t_air,Ta,Ca=dm.load_ambient()

def drying_time(props, amb, rad, t_horizon=110*3600., dt=20.0):
    o=dm.solve_cylinder(props, amb, rad, t_end=t_horizon, dt=dt, N=120, r_samp=rs, n_picard=3, save_every=2)
    tt=o['times']; Cm=o['Cr'].max(axis=1)
    if (Cm<0.15).any():
        i=int(np.argmax(Cm<0.15))
        t=tt[i-1]+(Cm[i-1]-0.15)/(Cm[i-1]-Cm[i])*(tt[i]-tt[i-1])
        return t/3600.0, o
    return np.inf, o

class P_hm( dm.PropsQ23 ):
    def __init__(self,f): self.hm=8e-7*f
class P_D( dm.PropsQ23 ):
    def __init__(self,f): self.f=f
    def D(self,C,T): return self.f*dm.PropsQ23.D(self,C,T)

cases=[('base',dm.PropsQ23(),dm.Ambient(t_air,Ta,Ca)),
       ('hm x0.5',P_hm(0.5),dm.Ambient(t_air,Ta,Ca)),
       ('hm x2',P_hm(2.0),dm.Ambient(t_air,Ta,Ca)),
       ('D x0.8',P_D(0.8),dm.Ambient(t_air,Ta,Ca)),
       ('D x1.2',P_D(1.2),dm.Ambient(t_air,Ta,Ca)),
       ('Tair 45',dm.PropsQ23(),dm.Ambient(t_air,Ta,Ca,T_const=45.0)),
       ('Tair 55',dm.PropsQ23(),dm.Ambient(t_air,Ta,Ca,T_const=55.0)),
       ('Cair 0.04',dm.PropsQ23(),dm.Ambient(t_air,Ta,Ca,C_const=0.04)),
       ('Cair 0.06',dm.PropsQ23(),dm.Ambient(t_air,Ta,Ca,C_const=0.06))]
res=[]
t0=time.time()
for name,p,a in cases:
    td,o = drying_time(p,a,dm.ConstRadius(0.02))
    C=o['Cr']; i24=int(np.argmin(abs(o['times']-24*3600))); i48=int(np.argmin(abs(o['times']-48*3600)))
    res.append(dict(case=name, t_dry_h=round(td,2), Cmax24=round(float(C[i24].max()),4),
                    Cmax48=round(float(C[i48].max()),4)))
    print(name, res[-1])
    np.savez_compressed(f'outputs/sens_{name.replace(" ","").replace(".","")}.npz', times=o['times'], Cr=C)
print('total',round(time.time()-t0,1))
import pandas as pd; pd.DataFrame(res).to_csv('outputs/sensitivity_q3.csv',index=False)

# ---- run_20261101_110057_53be77 ----

import sys, numpy as np, time
sys.path.insert(0,'code'); import drying_model as dm
rs=np.arange(0,20.0001,1.0)/1000.0
rt,rR=dm.load_radius(); rad=dm.Radius(rt,rR)
t_air,Ta,Ca=dm.load_ambient(); amb=dm.Ambient(t_air,Ta,Ca)
class P4D(dm.PropsQ4):
    def __init__(self,f): self.f=f
    def D(self,C,T): return self.f*dm.PropsQ4.D(self,C,T)
res=[]
for name,p in [('base',dm.PropsQ4()),('D x0.8',P4D(0.8)),('D x1.2',P4D(1.2))]:
    o=dm.solve_cylinder(p,amb,rad,t_end=110*3600.,dt=20.0,N=120,r_samp=rs,n_picard=3,save_every=3)
    Cm=o['Cr'].max(axis=1); tt=o['times']
    i=int(np.argmax(Cm<0.15)); t=tt[i-1]+(Cm[i-1]-0.15)/(Cm[i-1]-Cm[i])*(tt[i]-tt[i-1])
    print(name,'t_dry', round(t/3600,2),'h  R_end',round(o['R'][i]*100,4),'cm')
    res.append((name,t/3600))
    if name=='base':
        # validation metrics
        r=np.arange(0,20.0001,1.0)/1000.
        C=o['Cr']; flux=o['flux_m']*2*np.pi*o['R']
        idx=int(np.argmin(abs(tt-72*3600)))
        # for Q4 geometry shrinks: mass per unit length = integral 2 pi r C dr over current body
        def M(Crow, Rv):
            m=rs<=Rv+1e-12
            return np.trapezoid(Crow[m]*2*np.pi*rs[m], rs[m])
        print('mass initial', round(M(np.full(21,2.55),0.02),7), 'end(51.1h)', round(M(C[int(np.argmin(abs(tt-184006.)) )], o['R'][int(np.argmin(abs(tt-184006.)))]),7),
              'flux integral', round(np.trapezoid(flux[:int(np.argmin(abs(tt-184006.)))+1], tt[:int(np.argmin(abs(tt-184006.)))+1]),7))

# ---- run_20261101_110208_2a99e6 ----

src=open('code/drying_model.py').read()
# add accumulators
src=src.replace("""               Tair=np.zeros(nsave), Cair=np.zeros(nsave), R=np.zeros(nsave))""",
"""               Tair=np.zeros(nsave), Cair=np.zeros(nsave), R=np.zeros(nsave),
               Mwater=np.zeros(nsave), Fcum=np.zeros(nsave))
    Fcum = 0.0""")
src=src.replace("""        out['Tsurf'][ksave] = Ts; out['Csurf'][ksave] = Cs
        ksave += 1""",
"""        out['Tsurf'][ksave] = Ts; out['Csurf'][ksave] = Cs
        out['Mwater'][ksave] = 2 * np.pi * R ** 2 * np.sum(C * xi_c * dxi)
        out['Fcum'][ksave] = Fcum
        ksave += 1""")
src=src.replace("""        T, C = Tnew, Cnew
        if n % save_every == 0:""",
"""        T, C = Tnew, Cnew
        Cs_now = (C[-1] + (props.hm * (Rnew * dxi / 2) / props.D(C[-1], T[-1])) * Cair) / \\
                 (1.0 + props.hm * (Rnew * dxi / 2) / props.D(C[-1], T[-1]))
        Fcum += 2 * np.pi * Rnew * props.hm * (Cs_now - Cair) * dt
        if n % save_every == 0:""")
src=src.replace("""    for key in ('times', 'Tr', 'Cr', 'Tsurf', 'Csurf', 'flux_h', 'flux_m', 'Tair', 'Cair', 'R'):""",
"""    for key in ('times', 'Tr', 'Cr', 'Tsurf', 'Csurf', 'flux_h', 'flux_m', 'Tair', 'Cair', 'R',
                'Mwater', 'Fcum'):""")
open('code/drying_model.py','w').write(src)

import sys, numpy as np, importlib
sys.path.insert(0,'code'); import drying_model as dm; importlib.reload(dm)
rs=np.arange(0,20.0001,1.0)/1000.0
t_air,Ta,Ca=dm.load_ambient(); amb=dm.Ambient(t_air,Ta,Ca)
o2=dm.solve_cylinder(dm.PropsQ23(),amb,dm.ConstRadius(0.02),t_end=60*3600.,dt=10.0,N=120,r_samp=rs,n_picard=3,save_every=6)
i=-1
print('Q2 mass: removed', round(o2['Mwater'][0]-o2['Mwater'][i],7),'flux',round(o2['Fcum'][i],7),
      'rel',round(abs((o2['Mwater'][0]-o2['Mwater'][i])-o2['Fcum'][i])/(o2['Mwater'][0]-o2['Mwater'][i])*100,4),'%')
print('Q2 check fields reproduce:', np.abs(o2['Cr'][i]-np.load('outputs/q23_fields.npz')['Cr'][int(np.argmin(abs(np.load('outputs/q23_fields.npz')['times']-60*3600)))]).max())
rt,rR=dm.load_radius(); rad=dm.Radius(rt,rR)
o4=dm.solve_cylinder(dm.PropsQ4(),amb,rad,t_end=60*3600.,dt=10.0,N=120,r_samp=rs,n_picard=3,save_every=6)
i=int(np.argmin(abs(o4['times']-51.1128*3600)))
print('Q4 mass: removed', round(o4['Mwater'][0]-o4['Mwater'][i],7),'flux',round(o4['Fcum'][i],7),
      'rel',round(abs((o4['Mwater'][0]-o4['Mwater'][i])-o4['Fcum'][i])/(o4['Mwater'][0]-o4['Mwater'][i])*100,4),'%')

# ---- run_20261101_110301_dfe00d ----

import sys, numpy as np, importlib
sys.path.insert(0,'code'); import drying_model as dm; importlib.reload(dm)
rs=np.arange(0,20.0001,1.0)/1000.0
t_air,Ta,Ca=dm.load_ambient(); amb=dm.Ambient(t_air,Ta,Ca)
rt,rR=dm.load_radius(); rad=dm.Radius(rt,rR)
o=dm.solve_cylinder(dm.PropsQ4(),amb,rad,t_end=52*3600.,dt=10.0,N=120,r_samp=rs,n_picard=3,save_every=6)
tt=o['times']; R=o['R']; X=o['Mwater']/(2*np.pi*R**2)
# model implies dX/dt = -(hm/R)(Cs-Cair)
rhs = -(8e-7/R)*(o['Csurf']-o['Cair'])
lhs = np.gradient(X, tt)
m = tt>60
print('Q4 transformed-balance: max rel diff over records', round(float(np.max(np.abs(lhs[m]-rhs[m])/np.abs(rhs[m]))),4))
print('integrated: int lhs', round(np.trapezoid(lhs[m],tt[m]),7), ' int rhs', round(np.trapezoid(rhs[m],tt[m]),7))
np.savez_compressed('outputs/q4_check.npz', times=tt, X=X, R=R, Csurf=o['Csurf'], Cair=o['Cair'])

# ---- run_20261101_110329_ddbb05 ----

import numpy as np, json
d=np.load('outputs/q23_fields.npz'); tt=d['times']; C=d['Cr']; T=d['Tr']; rs=d['rs']
t_dry=57.5759
cols=[0,5,10,15,20]
def row(arr,times,t,cs):
    k=int(np.argmin(abs(times-t))); return ' & '.join(f'{arr[k][c]:.4f}' for c in cs)
lines=[]
for h in range(6,55,6):
    lines.append(f'{h} & '+row(C,tt,h*3600,cols)+r' \\')
lines.append(f'{t_dry:.2f} & '+row(C,tt,t_dry*3600,cols)+r' \\')
open('outputs/table5.tex','w').write('\n'.join(lines))
print('\n'.join(lines))
# Table 3/4
t34=[]
for h in [0.5,1,1.5,2,2.5,3.0]:
    t34.append(f'{h:.1f} & '+row(T,tt,h*3600,cols)+r' \\')
open('outputs/table3.tex','w').write('\n'.join(t34))
t44=[]
for h in [0.5,1,1.5,2,2.5,3.0]:
    t44.append(f'{h:.1f} & '+row(C,tt,h*3600,cols)+r' \\')
open('outputs/table4.tex','w').write('\n'.join(t44))
# Table 6
d4=np.load('outputs/q4_fields.npz'); t4=d4['times']; C4=d4['Cr']; R4=d4['R']
t_dry4=51.1128
def row6(k):
    Rcm=R4[k]*100
    vals=[f'{C4[k][c]:.4f}' if rs[c]*100<=Rcm+1e-9 else '--' for c in [0,5,10,15]]
    return ' & '.join(vals)+f' & {d4["Csurf"][k]:.4f} & {Rcm:.4f}'
l6=[]
for h in range(6,49,6):
    k=int(np.argmin(abs(t4-h*3600))); l6.append(f'{h} & '+row6(k)+r' \\')
k=int(np.argmin(abs(t4-t_dry4*3600))); l6.append(f'{t_dry4:.2f} & '+row6(k)+r' \\')
open('outputs/table6.tex','w').write('\n'.join(l6))
print('\n--- table6 ---'); print('\n'.join(l6))
# numbers for the text
print('Q2 avg moisture 0,6,12,24,48,57.58 h:',
      [round(float(np.trapezoid(C[int(np.argmin(abs(tt-h*3600)))]*2*np.pi*rs,rs)/(np.pi*0.02**2)),4) for h in [0,6,12,24,48,57.58]])
print('Q2 surface C at 3,6,12,24 h:', [round(float(d['Csurf'][int(np.argmin(abs(tt-h*3600)))]),4) for h in [3,6,12,24]])
print('Q4 avg moisture (material coord) at 0,6,12,24,48,51.1:',
      [round(float(np.trapezoid(C4[int(np.argmin(abs(t4-h*3600)))]*2*np.pi*rs,rs)/(np.pi*R4[int(np.argmin(abs(t4-h*3600)))]**2)),4) for h in [0,6,12,24,48,51.1]])
print('Q1: Biot heat',25*0.02/0.36,'Biot mass', 8e-7*0.02/(7e-9*np.exp(-0.89/2.55)))
print('Q2: D(C0,323)', 2.4e-3*np.exp(-0.45/2.55)*np.exp(-3850/323.15), 'Q4 D(C0,323)', 4.2e-4*np.exp(-0.30/2.55)*np.exp(-3850/323.15))

# ---- run_20261101_110352_f7ab18 ----

import numpy as np, matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size':9,'figure.dpi':150,'savefig.dpi':220,'axes.grid':True,
                     'grid.alpha':0.3,'mathtext.fontset':'cm','font.family':'DejaVu Sans'})
import os; os.makedirs('outputs/figures',exist_ok=True)
# ---------- fig1 Q1 profiles
d=np.load('outputs/q1_fields.npz'); tt=d['times']; T=d['Tr']; C=d['Cr']; rs=d['rs']*100
fig,ax=plt.subplots(1,2,figsize=(7.2,2.9))
sel=[300,600,900,1200,1500,1800]
cmap=plt.cm.viridis
for i,t in enumerate(sel):
    k=int(np.argmin(abs(tt-t)))
    ax[0].plot(rs,T[k],color=cmap(i/5),label=f'{t} s')
    ax[1].plot(rs,C[k],color=cmap(i/5),label=f'{t} s')
ax[0].plot(rs,np.interp(tt[sel[-1]],tt,d['Tair'])*np.ones_like(rs),'k--',lw=0.8,label='air')
ax[0].set_xlabel('r / cm'); ax[0].set_ylabel('T / °C'); ax[0].set_title('(a) Temperature')
ax[1].set_xlabel('r / cm'); ax[1].set_ylabel('C / (kg/kg)'); ax[1].set_title('(b) Moisture content')
ax[1].set_ylim(1.4,2.6)
ax[0].legend(fontsize=6.5,ncol=2); ax[1].legend(fontsize=6.5,ncol=2)
plt.tight_layout(); plt.savefig('outputs/figures/fig1_q1_profiles.png'); plt.close()

# ---------- fig2 Q2/Q3 histories
d=np.load('outputs/q23_fields.npz'); tt=d['times']/3600; C=d['Cr']; T=d['Tr']; rs_cm=d['rs']*100
Cavg=np.trapezoid(C*2*np.pi*d['rs'],d['rs'],axis=1)/(np.pi*0.02**2)
fig,ax=plt.subplots(1,2,figsize=(7.2,2.9))
ax[0].plot(tt,C[:,0],label='centre')
ax[0].plot(tt,C[:,-1],label='surface')
ax[0].plot(tt,Cavg,'--',label='mean')
ax[0].axhline(0.15,color='r',lw=0.8,ls=':')
ax[0].axhline(0.05,color='gray',lw=0.8,ls=':')
ax[0].set_yscale('log'); ax[0].set_xlim(0,60); ax[0].set_xlabel('t / h'); ax[0].set_ylabel('C / (kg/kg)')
ax[0].set_title('(a) Moisture history (Q2/Q3)'); ax[0].legend(fontsize=7)
ax[1].plot(tt,T[:,0],label='centre'); ax[1].plot(tt,T[:,-1],label='surface')
ax[1].plot(tt,d['Tair'],'k--',lw=0.8,label='air')
ax[1].set_xlim(0,6); ax[1].set_xlabel('t / h'); ax[1].set_ylabel('T / °C'); ax[1].legend(fontsize=7)
ax[1].set_title('(b) Temperature history')
plt.tight_layout(); plt.savefig('outputs/figures/fig2_q23_histories.png'); plt.close()

# ---------- fig3 contour Q2/Q3
sel=tt<=62
fig,ax=plt.subplots(1,1,figsize=(4.4,3.0))
cs=ax.contourf(rs_cm,tt[sel],C[sel],levels=np.linspace(0.05,2.55,26),cmap='viridis')
ct=ax.contour(rs_cm,tt[sel],C[sel],levels=[0.15],colors='r',linewidths=1.2)
ax.clabel(ct,fmt='%.2f',fontsize=7)
ax.set_xlabel('r / cm'); ax.set_ylabel('t / h'); ax.set_title('C field (Q2/Q3)')
plt.colorbar(cs,label='C / (kg/kg)')
plt.tight_layout(); plt.savefig('outputs/figures/fig3_q23_field.png'); plt.close()

# ---------- fig4 Q4 field with shrinkage
d4=np.load('outputs/q4_fields.npz'); t4=d4['times']/3600; C4=d4['Cr']; R4=d4['R']*100
Cm=np.where(rs_cm[None,:]<=R4[:,None]+1e-9, C4, np.nan)
fig,ax=plt.subplots(1,2,figsize=(7.2,2.9),gridspec_kw={'width_ratios':[2.2,1]})
cs=ax[0].contourf(rs_cm,t4,Cm,levels=np.linspace(0.05,2.55,26),cmap='viridis')
ct=ax[0].contour(rs_cm,t4,Cm,levels=[0.15],colors='r',linewidths=1.2)
ax[0].clabel=None
ax[0].plot(R4,t4,'w-',lw=1.2); ax[0].set_xlabel('r / cm'); ax[0].set_ylabel('t / h')
ax[0].set_title('C field with shrinkage (Q4)'); plt.colorbar(cs,ax=ax[0],label='C / (kg/kg)')
ax[1].plot(t4,R4,'b-'); ax[1].set_xlabel('t / h'); ax[1].set_ylabel('R(t) / cm'); ax[1].set_title('(b) radius (附件2)')
plt.tight_layout(); plt.savefig('outputs/figures/fig4_q4_field.png'); plt.close()

# ---------- fig5 sensitivity
import pandas as pd
s=pd.read_csv('outputs/sensitivity_q3.csv')
fig,ax=plt.subplots(1,1,figsize=(5.6,2.8))
ax.barh(s['case'][::-1], s['t_dry_h'][::-1], color='steelblue', height=0.6)
ax.axvline(57.58,color='r',ls='--',lw=0.9)
for i,(c,v) in enumerate(zip(s['case'][::-1], s['t_dry_h'][::-1])):
    ax.text(v+0.4,i,f'{v:.1f}',va='center',fontsize=7)
ax.set_xlabel('drying time / h'); ax.set_title('Sensitivity of Q3 drying time')
plt.tight_layout(); plt.savefig('outputs/figures/fig5_sensitivity.png'); plt.close()
print([f for f in sorted(os.listdir('outputs/figures'))])

# ---- run_20261101_110457_622bda ----

import numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
import sys, importlib
sys.path.insert(0,'code'); import drying_model as dm; importlib.reload(dm)
from scipy.special import j0, j1
from scipy.optimize import brentq
plt.rcParams.update({'font.size':9,'figure.dpi':150,'savefig.dpi':220,'axes.grid':True,'grid.alpha':0.3})
def series(Bi,Fo,r,nt=80):
    roots=[];x=1e-6
    for n in range(nt):
        lo=x+1e-6; hi=x+np.pi*0.999
        f=lambda z: z*j1(z)-Bi*j0(z)
        if f(lo)*f(hi)>0: x=hi; continue
        roots.append(brentq(f,lo,hi)); x=hi
    lam=np.array(roots); Cn=2*j1(lam)/(lam*(j0(lam)**2+j1(lam)**2))
    return np.sum(Cn[:,None]*j0(lam[:,None]*np.atleast_1d(r)[None,:])*np.exp(-lam**2*np.array(Fo))[:,None],axis=0)
class StepAmb:
    def __call__(self,tt): return 50.0,0.0
R=0.02; h=25.;k=0.36;alpha=k/(820*2600); D0=7e-9*np.exp(-0.89/2.55); hm=8e-7
rr=np.linspace(0,1,41)
o=dm.solve_cylinder(dm.PropsQ1(),StepAmb(),dm.ConstRadius(R),t_end=900.,dt=1.0,N=120,r_samp=rr*R)
class Pconst(dm.PropsQ1):
    def D(self,C,T): return D0*np.ones_like(C)
b2=dm.Ambient(*dm.load_ambient())
rq=np.array([0,0.25,0.5,0.75,0.95,1.0])
o2=dm.solve_cylinder(Pconst(),b2,dm.ConstRadius(R),t_end=1800.,dt=1.0,N=120,r_samp=rq*R)
fig,ax=plt.subplots(1,2,figsize=(7.2,2.8))
for t in [60,300,900]:
    idx=int(np.argmin(abs(o['times']-t)))
    ax[0].plot(rr*R*100,o['Tr'][idx],'-',lw=1)
    ax[0].plot(rr*R*100,50-22*series(h*R/k,alpha*t/R**2,rr),'o',ms=2.2,mfc='none',mew=0.7)
ax[0].plot([],[],'k-',label='numerical (FV)'); ax[0].plot([],[],'ko',mfc='none',ms=3,label='analytic series')
ax[0].set_xlabel('r / cm'); ax[0].set_ylabel('T / °C'); ax[0].set_title('(a) heat, t = 60/300/900 s'); ax[0].legend(fontsize=7)
for t in [600,1800]:
    idx=int(np.argmin(abs(o2['times']-t)))
    Cair=float(np.interp(t,b2.t,b2.Ca))
    ax[1].plot(rq*2,o2['Cr'][idx],'-o',ms=3,lw=1,label=f'numerical, {t} s')
    ax[1].plot(rq*2,Cair+(2.55-Cair)*series(hm*R/D0,D0*t/R**2,rq),'x',ms=5,mew=1,label=f'analytic, {t} s')
ax[1].set_xlabel('r / cm'); ax[1].set_ylabel('C / (kg/kg)'); ax[1].set_title('(b) moisture, constant-D check'); ax[1].legend(fontsize=6.5)
plt.tight_layout(); plt.savefig('outputs/figures/fig6_validation.png'); plt.close()
# errors
e=[]
for t in [60,300,900]:
    idx=int(np.argmin(abs(o['times']-t))); e.append(np.abs(o['Tr'][idx]-(50-22*series(h*R/k,alpha*t/R**2,rr))).max())
print('heat max err (C):', np.round(e,4))
e2=[]
for t in [600,1800]:
    idx=int(np.argmin(abs(o2['times']-t))); Cair=float(np.interp(t,b2.t,b2.Ca))
    e2.append(np.abs(o2['Cr'][idx]-(Cair+(2.55-Cair)*series(hm*R/D0,D0*t/R**2,rq))).max())
print('mass max err (kg/kg) const-D:', np.round(e2,4))
print('ok')

# ---- run_20261101_110634_7c8fba ----

import numpy as np
d=np.load('outputs/q23_fields.npz'); tt=d['times']/3600; C=d['Cr']; rs=d['rs']
Cavg=np.trapezoid(C*2*np.pi*rs,rs,axis=1)/(np.pi*0.02**2)
m=(tt>=24)&(tt<=54)
p=np.polyfit(tt[m],np.log(C[m,0]-0.05),1)
print('fitted lambda (center-0.05) 24-54h:', -p[0], 'per h; tau', -1/p[0])
p2=np.polyfit(tt[m],np.log(Cavg[m]-0.05),1); print('mean lambda', -p2[0])
# drying rate of mean
rate=-np.gradient(Cavg,tt)
for h in [0.5,1,2,3,6,9,12,18,24]:
    k=int(np.argmin(abs(tt-h))); print('t',h,'h  dCbar/dt',round(float(rate[k]),5),'per h')
print('max rate at', round(float(tt[np.argmax(rate)]),2),'h')
# Q4 velocity vs diffusion
rt,rR=np.load('outputs/q4_fields.npz')['times'],np.load('outputs/q4_fields.npz')['R']
dR=np.gradient(rR,rt)
print('max |dR/dt| m/s', np.abs(dR).max(), 'at h', rt[np.argmax(np.abs(dR))]/3600)
print('|Rdot|/R max', (np.abs(dR)/rR).max(), ' typical D/R^2 early', 2.5e-9/0.02**2)

# ---- run_20261101_111032_0152fa ----

import pandas as pd, numpy as np, matplotlib
matplotlib.use('Agg'); import matplotlib.pyplot as plt
for f in ['result1.xlsx','result2.xlsx','result3.xlsx','result4.xlsx']:
    x=pd.ExcelFile(f)
    print(f, x.sheet_names)
    d=pd.read_excel(f, sheet_name=0, nrows=3)
    print(list(d.columns)[:5], list(d.columns)[-3:], d.shape)
d3=pd.read_excel('result3.xlsx'); print('result3 shape',d3.shape, 'last row time',d3.iloc[-1,0])
d4=pd.read_excel('result4.xlsx'); print('result4 shape',d4.shape, 'last row', d4.iloc[-1,0])
print('result4 last rows\n', d4.iloc[-2:, :12].to_string())
d2=pd.read_excel('result2.xlsx', sheet_name='温度'); print('result2 T shape',d2.shape,'last t',d2.iloc[-1,0])
d1=pd.read_excel('result1.xlsx', sheet_name='水分浓度'); print('result1 C shape',d1.shape,'row1800', d1.iloc[-1,:6].tolist())

# --- regenerate sensitivity figure with clean labels
s=pd.read_csv('outputs/sensitivity_q3.csv')
plt.rcParams.update({'font.size':9,'figure.dpi':150,'savefig.dpi':220,'axes.grid':True,'grid.alpha':0.3})
fig,ax=plt.subplots(figsize=(5.8,2.9))
y=np.arange(len(s))[::-1]
ax.barh(y, s['t_dry_h'], color='steelblue', height=0.62)
ax.axvline(57.58,color='r',ls='--',lw=0.9)
ax.set_yticks(y); ax.set_yticklabels(s['case'])
for yy,v in zip(y,s['t_dry_h']):
    ax.text(v+0.6, yy, f'{v:.1f}', va='center', fontsize=7.5)
ax.set_xlim(0,78); ax.set_xlabel('drying time / h')
ax.set_title('Sensitivity of drying time (dashed: baseline 57.58 h)')
plt.tight_layout(); plt.savefig('outputs/figures/fig6_sensitivity_v2.png'); plt.close()
print('fig ok')