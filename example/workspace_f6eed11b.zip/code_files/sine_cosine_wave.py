import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime

# 设置时间范围和采样率
t = np.linspace(0, 2, 1000)  # 从0到2秒，1000个点

# 生成正弦波和余弦波
sin_wave = np.sin(2 * np.pi * 1 * t)  # 频率为1Hz的正弦波
cos_wave = np.cos(2 * np.pi * 2 * t)  # 频率为2Hz的余弦波

# 叠加波形
combined_wave = sin_wave + cos_wave

# 绘制图像
plt.figure(figsize=(10, 6))
plt.plot(t, sin_wave, label='Sine Wave (1Hz)')
plt.plot(t, cos_wave, label='Cosine Wave (2Hz)')
plt.plot(t, combined_wave, label='Combined Wave', linestyle='--')
plt.xlabel('Time (s)')
plt.ylabel('Amplitude')
plt.title('Sine and Cosine Waves and Their Combination')
plt.legend()
plt.grid(True)

# 保存图像
output_filename = f'outputs/plots/sine_cosine_wave_{datetime.now().strftime("%Y%m%d_%H%M%S")}.png'
plt.savefig(output_filename)
plt.show()